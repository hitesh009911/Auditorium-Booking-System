<?php
// Connect to the database
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "booking"; // Your database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $description = $_POST["description"];
    $location = $_POST["location"];
    $date = $_POST["date"];
    $category = $_POST["category"];
    $seating_capacity = $_POST["seating_capacity"];

    // Prepare SQL statement
    $sql = "INSERT INTO events (title, description, location, date, category, seating_capacity) 
            VALUES ('$title', '$description', '$location', '$date', '$category', $seating_capacity)";

    if (mysqli_query($conn, $sql)) {
        // Get the ID of the last inserted event
        $event_id = mysqli_insert_id($conn);
        
        // Redirect to the details page with event ID as parameter
        header("Location: details.php?id=$event_id");
        exit(); // Stop further execution
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
