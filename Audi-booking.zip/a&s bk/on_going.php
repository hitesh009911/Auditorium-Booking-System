  <?php
        // Connect to the database
        $servername = "localhost";
        $username = "root"; // Your MySQL username
        $password = ""; // Your MySQL password
        $dbname = "booking"; // Your database name

        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Fetch ongoing events
        $sql = "SELECT * FROM events";
        $result = mysqli_query($conn, $sql);

        $row = mysqli_fetch_assoc($result);
        if ($row) {
            echo "<li>" . $row["title"] . " - " . $row["date"] . "</li>";
        } else {
            echo "<li>No ongoing events.</li>";
        }

        // Close the database connection
        mysqli_close($conn);
        ?>