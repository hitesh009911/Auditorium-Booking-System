// script.js
document.addEventListener("DOMContentLoaded", function() {
    // Get the sign-in and sign-up buttons
    var signInBtn = document.getElementById("signInBtn");
    var signUpBtn = document.getElementById("signUpBtn");

    // Add click event listeners to the buttons
    signInBtn.addEventListener("click", function() {
        // Redirect to sign-in page
        window.location.href = "signin.php";
    });

    signUpBtn.addEventListener("click", function() {
        // Redirect to sign-up page
        window.location.href = "signup.php";
    });
});
