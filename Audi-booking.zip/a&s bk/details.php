<?php
// Connect to the database
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "booking"; // Your database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the event ID is provided in the URL
if (isset($_GET['id'])) {
    $event_id = $_GET['id'];

    // Fetch event details using the provided event ID
    $sql_event = "SELECT * FROM events WHERE id = $event_id";
    $result_event = mysqli_query($conn, $sql_event);

    if (mysqli_num_rows($result_event) > 0) {
        $event = mysqli_fetch_assoc($result_event);

        // Fetch registered members for the event
        $sql_members = "SELECT * FROM bookings WHERE event_id = $event_id";
        $result_members = mysqli_query($conn, $sql_members);
    } else {
        echo "Event not found.";
        exit();
    }
} else {
    echo "Event ID not provided.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Details</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Event Details</h1>
    <p>Title: <?php echo $event['title']; ?></p>
    <p>Description: <?php echo $event['description']; ?></p>
    <p>Location: <?php echo $event['location']; ?></p>
    <p>Date: <?php echo $event['date']; ?></p>
    <p>Category: <?php echo $event['category']; ?></p>
    <p>Seating Capacity: <?php echo $event['seating_capacity']; ?></p>
    
    <h2>Registered Members</h2>
    <?php if (mysqli_num_rows($result_members) > 0): ?>
    <table>
        <tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Email</th>
        </tr>
        <?php while ($member = mysqli_fetch_assoc($result_members)): ?>
        <tr>
            <td><?php echo $member['user_id']; ?></td>
            <td><?php echo $member['name']; ?></td>
            <td><?php echo $member['email']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
    <?php else: ?>
    <p>No members have registered for this event.</p>
    <?php endif; ?>

    <a href="events admin.html">Back to Create Event</a>
</body>
</html>

<?php
// Close the database connection
mysqli_close($conn);
?>
