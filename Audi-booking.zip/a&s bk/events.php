<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	/* Import the Roboto font from Google Fonts */
@import url('https://fonts.googleapis.com/css?family=Roboto');

/* Apply the Roboto font and set background color for the body */
body {
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f9f9f9;
}

/* Center the heading and give it some margin */
h1 {
    text-align: center;
    margin: 20px 0;
}

/* Style the events list */
ul {
    list-style-type: none;
    padding: 0;
    margin: 0 auto;
    max-width: 600px;
}

/* Style the event list items */
li {
    margin: 10px 0;
    padding: 10px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Style the event links */
a {
    color: #333;
    text-decoration: none;
    transition: color 0.3s;
}

/* Add hover effect to the event links */
a:hover {
    color: #04AA6D;
}
</style>
    <title>Events Page</title>
</head>
<body>
    <h1>Events</h1>
    <ul>
        <?php
        // Connect to the database
        $servername = "localhost";
        $username = "root"; // Your MySQL username
        $password = ""; // Your MySQL password
        $dbname = "booking"; // Your database name

        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Fetch events from the database
        $sql = "SELECT id, title FROM events";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<li><a href='event_details.php?id=" . $row['id'] . "'>" . $row['title'] . "</a></li>";
            }
        } else {
            echo "<li>No events available.</li>";
        }

        // Close the database connection
        mysqli_close($conn);
        ?>
    </ul>
</body>
</html>
