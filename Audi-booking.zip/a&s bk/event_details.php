<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Details</title>
</head>
<body>
    <h1>Event Details</h1>
    <?php
    // Connect to the database
    $servername = "localhost";
    $username = "root"; // Your MySQL username
    $password = ""; // Your MySQL password
    $dbname = "booking"; // Your database name

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch event details based on ID from the database
    if (isset($_GET['id'])) {
        $eventId = $_GET['id'];
        $sql = "SELECT title, description FROM events WHERE id=$eventId";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            echo "<p>Event Name: " . $row['title'] . "</p>";
            echo "<p>Description: " . $row['description'] . "</p>";
        } else {
            echo "<p>No event details found.</p>";
        }
    } else {
        echo "<p>No event selected.</p>";
    }

    // Close the database connection
    mysqli_close($conn);
    ?>

    <button id="registerButton">Register</button>
    <div id="confirmationMessage" style="display: none;">
        <p>Are you sure you want to register for this event?</p>
        <button id="confirmButton">Confirm</button>
        <button id="cancelButton">Cancel</button>
    </div>
    <p id="thankYouMessage" style="display: none;">Thank you for registering!</p>

    <a href="events.php">Back to Main Page</a>

    <script>
        document.getElementById("registerButton").addEventListener("click", function() {
            var thankYouMessage = document.getElementById("thankYouMessage");
            if (thankYouMessage.style.display !== "block") {
                var confirmationMessage = document.getElementById("confirmationMessage");
                confirmationMessage.style.display = "block";
            }
        });

        document.getElementById("confirmButton").addEventListener("click", function() {
            var confirmationMessage = document.getElementById("confirmationMessage");
            confirmationMessage.style.display = "none";
            var thankYouMessage = document.getElementById("thankYouMessage");
            thankYouMessage.style.display = "block";
        });

        document.getElementById("cancelButton").addEventListener("click", function() {
            var confirmationMessage = document.getElementById("confirmationMessage");
            confirmationMessage.style.display = "none";
        });
    </script>
</body>
</html>
