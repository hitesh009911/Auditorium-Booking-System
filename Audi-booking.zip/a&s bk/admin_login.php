<?php
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "booking"; // Your database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
// Start the session
session_start();

// Check if the admin is already logged in, if yes, redirect to admin dashboard
if(isset($_SESSION["admin_loggedin"]) && $_SESSION["admin_loggedin"] === true){
    header("location: index.html");
    exit;
}

// Check if the form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate email and password
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Connect to the database
    $servername = "localhost";
    $username = "root"; // Your MySQL username
    $password = ""; // Your MySQL password
    $dbname = "booking"; // Your database name

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement to fetch admin details
    $sql = "SELECT * FROM admin WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if admin exists
    if ($result->num_rows == 1) {
        $admin = $result->fetch_assoc();
        
        // Verify password
        if(password_verify($password, $admin["password"])) {
            // Password is correct, start a new session
            $_SESSION["admin_loggedin"] = true;
            $_SESSION["admin_email"] = $admin["email"];
            
            // Redirect to admin dashboard
            header("location: index.html");
            exit;
        } else {
            // Incorrect password
            echo "Incorrect password";
        }
    } else {
        // Admin not found
        echo "Admin not found";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
